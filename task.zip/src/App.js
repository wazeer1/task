import logo from './logo.svg';
import './App.css';
import HeroSect from './components/HeroSect';
import Layout from './components/Layout';

function App() {
  return (
    <div className='bg-black text-white'>
      <Layout/>
    </div>
  );
}

export default App;
